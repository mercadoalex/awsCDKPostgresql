import * as cdk from '@aws-cdk/core';
export declare class AwsCdkPostgresqlStack extends cdk.Stack {
    constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps);
}
